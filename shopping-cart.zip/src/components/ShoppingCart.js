import { Offcanvas, Stack } from "react-bootstrap";
import { useShoppingCart } from "../context/ShoppingCartContext";
import { formatCurrency } from "../utilities/formatCurrency";
import CartItem from "./CartItem";
import storeItems from "../data/items.json";
import { useEffect, useState } from "react";

const ShoppingCart = ({ isOpen }) => {
  const { closeCart, cartItems } = useShoppingCart();
  const [user, setUser] = useState(null);

  function subtotal() {
    const subtotal = cartItems.reduce((total, cartItem) => {
      const item = storeItems.find((i) => i.id === cartItem.id);
      return total + (item?.price || 0) * cartItem.quantity;
    }, 0);
    return subtotal;
  }

  const discount = () => {
    const total = subtotal();
    return user !== null && total * (user.role === "associate" ? 0.05 : 0.2);
  };

  const total = () => {
    let total = 0;
    if (user?.role === "diamond") {
      cartItems.forEach((cartItem) => {
        if (cartItem.name === "Kone" && cartItem.quantity > 2) {
          total += cartItem.price = 2588.99 * cartItem.quantity;
        } else if (
          cartItem.name === "Ironhide Catridge" &&
          cartItem.quantity > 2
        ) {
          total += cartItem.price * (cartItem.quantity - 1);
        } else {
          total += cartItem.price * cartItem.quantity;
        }
      });
    } else {
      total = subtotal();
    }

    return total;
  };

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
      setUser(user);
    }
  }, []);

  return (
    <Offcanvas show={isOpen} onHide={closeCart} placement="end">
      <Offcanvas.Header closeButton>
        <Offcanvas.Title>Cart</Offcanvas.Title>
      </Offcanvas.Header>
      <Offcanvas.Body>
        <Stack gap={3}>
          {cartItems.map((item) => (
            <CartItem key={item.id} {...item} />
          ))}
          {cartItems.length > 0 && (
            <>
              <div className="ms-auto fs-7">
                Subtotal: {formatCurrency(subtotal())}
              </div>
              {user && (
                <div className="ms-auto fs-7">
                  Discount: <del>{formatCurrency(discount())}</del>
                </div>
              )}
              <div className="ms-auto fw-bold border-top fs-5">
                Total: {formatCurrency(total() - discount())}
              </div>
            </>
          )}
        </Stack>
      </Offcanvas.Body>
    </Offcanvas>
  );
};

export default ShoppingCart;
