import { useShoppingCart } from "../context/ShoppingCartContext";

const { getItemQuantity } = useShoppingCart();

test("testing getItemQuantity", () => {
  expect(getItemQuantity(1)).toBe(0);
});
