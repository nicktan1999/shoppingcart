import { useState } from "react";
import { Col } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import { useNavigate } from "react-router-dom";
import users from "../data/users.json";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigator = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !password) {
      alert("Invalid Feilds");
    } else if (!users.find((user) => user.email === email)) {
      alert("Invalid Email");
    } else if (!users.find((user) => user.password === password)) {
      alert("Invalid Password");
    } else {
      const user = users.find(
        (user) => user.email === email && user.password === password
      );
      localStorage.setItem("user", JSON.stringify(user));
      navigator("/");
      window.location.reload();
    }
  };

  return (
    <div className="d-flex flex-column align-items-center justify-content-center">
      <h2 className="mt-2">Login</h2>
      <Row>
        <Col xs={4} style={{ minWidth: "400px", marginTop: "3rem" }}>
          <Form className="" onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter email"
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicCheckbox">
              <Form.Check type="checkbox" label="Check me out" />
            </Form.Group>
            <Button variant="primary" type="submit">
              Submit
            </Button>
          </Form>
        </Col>
      </Row>
    </div>
  );
}

export default Login;
